package org.practice;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeDetails {
	
	private  static void retrieveMethods(String sqlQuery) {
		
		Connection connection=null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "HR", "admin");
		
			String sql= sqlQuery;
			
			PreparedStatement prepareStatement = connection.prepareStatement(sql);
			
			ResultSet executeQuery = prepareStatement.executeQuery();
			
			while (executeQuery.next()) {
				
				
				String name = executeQuery.getString("first_name");
				
				System.out.println(name);
			}
		} 
		
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		finally {
			
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	
	public static void main(String[] args) {
		
		
		retrieveMethods("select * from employees");
	}

}
