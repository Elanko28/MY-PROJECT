package addtokart;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.util.List;

import ecomauto.LogRes;
import ecomauto.LoginDetails;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;

public class AddToKart {

	public static void main(String[] args) {

		// LOGIN DETAILS

		LoginDetails ld = new LoginDetails();
		ld.setUserEmail("elanko28@gmail.com");
		ld.setUserPassword("Elanko123");

		RequestSpecification logReqSpec = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.setContentType(ContentType.JSON).build();

		RequestSpecification givenReq = given().log().all().spec(logReqSpec).body(ld);

		LogRes lr = givenReq.when().post("/api/ecom/auth/login").then().log().all().assertThat().statusCode(200)
				.extract().response().as(LogRes.class);

		String token = lr.getToken();
		String userId = lr.getUserId();
		String message = lr.getMessage();
		System.out.println(token);
		System.out.println(userId);
		System.out.println(message);

		// CREATE PRODUCT

		RequestSpecification creProdReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).build();

		File f5 = new File("D:\\classes\\API\\Day 19\\TSHIRT.png");
		RequestSpecification creProdGiven5 = given().log().all().spec(creProdReq)
				.formParam("productName", "TSHIRT-ADDTOKART").formParam("productAddedBy", userId)
				.formParam("productCategory", "fashion").formParam("productSubCategory", "t-shirts")
				.formParam("productPrice", "1500").formParam("productDescription", "BEST TSHIRT")
				.formParam("productFor", "men").multiPart("productImage", f5);

		String creProdRes5 = creProdGiven5.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();

		System.out.println("PRODUCT CREATED");
		JsonPath js5 = new JsonPath(creProdRes5);
		String productId5 = js5.getString("productId");
		String mes5 = js5.getString("message");
		System.out.println(productId5);
		System.out.println(mes5);

		// ADD TO KART

		RequestSpecification addToReq = given().log().all().spec(logReqSpec).header("Authorization", token).body("{\r\n"
				+ "  \"_id\": \"" + userId + "\",\r\n" + "  \"product\": {\r\n" + "    \"_id\": \"" + productId5
				+ "\",\r\n" + "    \"productName\": \"TSHIRT\",\r\n" + "    \"productCategory\": \"fashion\",\r\n"
				+ "    \"productSubCategory\": \"t-shirts\",\r\n" + "    \"productPrice\": 1500,\r\n"
				+ "    \"productDescription\": \"BEST TSHIRT\",\r\n"
				+ "    \"productImage\": \"https://rahulshettyacademy.com/api/ecom/uploads/productImage_1729331070681.png\",\r\n"
				+ "    \"productRating\": \"0\",\r\n" + "    \"productTotalOrders\": \"0\",\r\n"
				+ "    \"productStatus\": true,\r\n" + "    \"productFor\": \"men\",\r\n" + "    \"productAddedBy\": \""
				+ userId + "\",\r\n" + "    \"__v\": 0\r\n" + "  }\r\n" + "}");

		String addToRes = addToReq.when().post("/api/ecom/user/add-to-cart").then().log().all().assertThat()
				.statusCode(200).extract().response().asString();

		System.out.println("ADD TO KART PRODUCT RESPONSE");
		JsonPath js = new JsonPath(addToRes);
		String mes = js.getString("message");
		System.out.println(mes);

		// CREATE ORDER

		RequestSpecification creOrReq = given().log().all().spec(logReqSpec).header("Authorization", token)
				.body("{\r\n" + "  \"orders\": [\r\n" + "    {\r\n" + "      \"country\": \"India\",\r\n"
						+ "      \"productOrderedId\": \"" + productId5 + "\"\r\n" + "    }\r\n" + "  ]\r\n" + "}");

		AddToKartRes as = creOrReq.when().post("/api/ecom/order/create-order").then().log().all().assertThat()
				.statusCode(201).extract().response().as(AddToKartRes.class);

		System.out.println("CREATE ORDER RESPONSE");
		List<String> or = as.getOrders();
		List<String> productOrderId = as.getProductOrderId();
		String message2 = as.getMessage();
		String orders = or.get(0);
		System.out.println(orders);
		// String productOrderId = productId5;
		System.out.println(productOrderId);
		System.out.println(message2);

		/*
		 * String creOrRes =
		 * addToReq.when().post("/api/ecom/order/create-order").then().log().all().
		 * assertThat() .statusCode(201).extract().response().asString();
		 * 
		 * JsonPath js2 = new JsonPath(creOrRes); List<String> or =
		 * js2.getList("orders"); String orders = or.get(0); String mes1 =
		 * js2.getString("message"); System.out.println(mes1); List<String> pd =
		 * js2.getList("productOrderId"); String productOrderId = pd.get(0);
		 * System.out.println(productOrderId);
		 */
		/*
		 * JsonPath js2 = new JsonPath(creOrRes); String orders =
		 * js2.getString("orders[0]"); System.out.println(orders); String productOrderId
		 * = js2.getString("productOrderId[0]"); System.out.println(productOrderId);
		 */
		// DELETE ORDER
		String delOrderRes = given().log().all().spec(creProdReq).pathParam("order", orders).when()
				.delete("/api/ecom/order/delete-order/{order}").then().log().all().assertThat().statusCode(200)
				.extract().response().asString();

		System.out.println("DELETE ORDER RESPONSE");
		JsonPath js3 = new JsonPath(delOrderRes);
		String mes2 = js3.getString("message");
		System.out.println(mes2);

		// DELETE PRODUCT

		RequestSpecification delProdReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).addPathParam("productId2", productId5).build();

		String delProdRes = given().log().all().spec(delProdReq).when()
				.delete("/api/ecom/product/delete-product/{productId2}").then().log().all().assertThat().statusCode(200)
				.extract().response().asString();

		System.out.println("DELETE PRODUCT RESPONSE");
		JsonPath js4 = new JsonPath(delProdRes);
		String mes3 = js4.getString("message");
		System.out.println(mes3);

	}
}
