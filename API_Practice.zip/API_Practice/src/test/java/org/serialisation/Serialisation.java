package org.serialisation;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.ArrayList;
import java.util.List;

import org.base.ReusableMethods;
import org.body.Body_Load;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import io.restassured.RestAssured;
import jdk.internal.org.jline.terminal.TerminalBuilder.SystemOutput;

public class Serialisation {

	public static void main(String[] args) throws JsonProcessingException {

		
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		
		PlaceDetails pd= new PlaceDetails();
		pd.setAccuracy("90");
		pd.setName("Infosys Technologies");
		pd.setPhone_number("(+91) 123 456 7890");
		pd.setAddress("29, navy mumbai");
		pd.setWebsite("http://google.com");
		pd.setLanguage("English-IN");
		
		Location l=new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		pd.setLocation(l);
		List<String> li=new ArrayList<>();
		li.add("herbal park");
		li.add("shop");
		pd.setTypes(li);
		
		System.out.println("");
		
		System.out.println("json file format");
		
		ObjectMapper mapper = new ObjectMapper();
		String js = mapper.writeValueAsString(pd);
		System.out.println(js);
		
		System.out.println("xml file format");

		
		XmlMapper mapper1=new XmlMapper();
		String xml = mapper1.writeValueAsString(pd);
		System.out.println(xml);
		
		GetPlaceDetails as = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body(pd).when().post("/maps/api/place/add/json").then().log().all().assertThat()
				.statusCode(200).body("scope", equalTo("APP")).body("status", equalTo("OK"))
				.header("Server", equalTo("Apache/2.4.52 (Ubuntu)")).extract().response().as(GetPlaceDetails.class);
		
		String status = as.getStatus();
		String place_id = as.getPlace_id();
		String scope = as.getScope();
		String reference = as.getReference();
		String id = as.getId();
		
		System.out.println("DESERIALISATION OF JSON RESPONSE");

		System.out.println("status"+" : "+status);
		System.out.println("place_id"+" : "+place_id);
		System.out.println("scope"+" : "+scope);
		System.out.println("reference"+" : "+reference);
		System.out.println("id"+" : "+id);
	}

}
