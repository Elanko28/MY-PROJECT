package org.deserialisation;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class Com5_Deserialisation {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://rahulshettyacademy.com";
	
		PostLocation as = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body(Body_Load.company5()).when().post("/maps/api/place/add/json").then().log().all().assertThat()
				.statusCode(200).body("scope", equalTo("APP")).body("status", equalTo("OK"))
				.header("Server", equalTo("Apache/2.4.52 (Ubuntu)")).extract().response().as(PostLocation.class);

		
		String pId = as.getPlace_id();
	
		// UPDATE
		
		String placeUpdate ="Bangalore-560001(1)";

		PutLocation as2 = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body("{\r\n" + "\"place_id\":\"" + pId + "\",\r\n"
						+ "\"address\":\""+placeUpdate+"\",\r\n"
						+ "\"key\":\"qaclick123\"\r\n" + "}\r\n" + "")
				.when().put("/maps/api/place/update/json").then().log().all().assertThat().statusCode(200).extract().response().			as(PutLocation.class);
		

		// GET THE UPDATE (TASK)

		GetLocation as3 = given().log().all().queryParam("key", "qaclick123").queryParam("place_id", pId).when()
				.get("/maps/api/place/get/json").then().log().all().assertThat().statusCode(200).extract().response().as(GetLocation.class);
		
	
		// DELETE THE PLACE

		DelLocation as4 = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body("{\r\n" + "    \"place_id\":\""+pId+"\"\r\n" + "}\r\n" + "").when()
				.delete("/maps/api/place/delete/json").then().log().all().assertThat().statusCode(200).extract().response().as(DelLocation.class);
		
		System.out.println(as4);
		
		System.out.println(as.getId());System.out.println(as.getPlace_id());System.out.println(as.getReference());
		System.out.println(as.getScope());System.out.println(as.getStatus());

		System.out.println(as2.getMsg());
		
		System.out.println(as3.getLocation().getLatitude());
		System.out.println(as3.getLocation().getLongitude());
		System.out.println(as3.getAccuracy());
		System.out.println(as3.getName());
		System.out.println(as3.getPhone_number());
		System.out.println(as3.getAddress());
		System.out.println(as3.getTypes());
		System.out.println(as3.getWebsite());
		System.out.println(as3.getLocation());


		System.out.println(as4.getStatus());

	}}
