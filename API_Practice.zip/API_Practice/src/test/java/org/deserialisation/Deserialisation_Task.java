package org.deserialisation;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.base.ReusableMethods;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class Deserialisation_Task {
	
	public static void main(String[] args) {
		RestAssured.baseURI = "https://rahulshettyacademy.com";

		// POST - ACCESS TOKEN
		String postRes = given().log().all()
				.formParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
				.formParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W").formParam("grant_type", "client_credentials")
				.formParam("scope", "trust").when().post("/oauthapi/oauth2/resourceOwner/token").then().log().all()
				.assertThat().statusCode(200).extract().response().asString();

		String access_token = ReusableMethods.rawToJason(postRes, "access_token");
		System.out.println("Access_Token :" + access_token);
		
		
		// Get - the details
		
		CourseDetails cd = given().log().all().queryParam("access_token",access_token).
		when().get("/oauthapi/getCourseDetails").
		then().log().all().extract().response().as(CourseDetails.class);
			System.out.println("1. PRINT THE API COURSE TITLE AND PRICE PRESENT IN FIRST POSITION");

		Courses c = cd.getCourses();
		List<Api> a = c.getApi();
		Api api = a.get(0);
		String courseTitle = api.getCourseTitle();
		String price = api.getPrice();
		System.out.println(courseTitle+" : "+price);
		
		System.out.println("2. PRINT THE EXPECTED COURSETITLE PRICE IN API\r\n");	
		
		String expected="SoapUI Webservices testing";
		
		for (int i = 0; i < a.size(); i++) {
				
			String courseTitle1 = cd.getCourses().getApi().get(i).getCourseTitle();
			if (expected.equalsIgnoreCase(courseTitle1)) {
				String price1 = cd.getCourses().getApi().get(i).getPrice();
				System.out.println(price1);
			}			
		}
		
		System.out.println("3. print the web automation coursetitle and price present in the second position");
					
			String webAutoCourseTitle = cd.getCourses().getWebAutomation().get(1).getCourseTitle();
			String price3 = cd.getCourses().getWebAutomation().get(1).getPrice();
			System.out.println(webAutoCourseTitle+" : "+price3);
			
			System.out.println("4.PRINT THE EXPECTED COURSETITLE PRICE IN WEB AUTOMATION");
			
			String expected1="Protractor";
			
			int autSize = cd.getCourses().getWebAutomation().size();
					
			for (int i = 0; i < autSize ; i++) {
					
				String courseTitle1 = cd.getCourses().getWebAutomation().get(i).getCourseTitle();
				if (expected1.equalsIgnoreCase(courseTitle1)) {
					String price1 = cd.getCourses().getWebAutomation().get(i).getPrice();
					System.out.println(price1);
				}			
			}
			
			System.out.println("5. print the mobile  coursetitle and price present in the first position");
			
			
			String mobCourseTitle = cd.getCourses().getMobile().get(0).getCourseTitle();
			String price4 = cd.getCourses().getMobile().get(0).getPrice();
			System.out.println(webAutoCourseTitle+" : "+price4);
			
			System.out.println("6.PRINT THE EXPECTED COURSETITLE PRICE IN MOBILE");
			
			String expected2="Appium-Mobile Automation using Java";
			
			int mobSize = cd.getCourses().getMobile().size();
					
			for (int i = 0; i < mobSize ; i++) {
					
				String courseTitle1 = cd.getCourses().getMobile().get(i).getCourseTitle();
				if (expected2.equalsIgnoreCase(courseTitle1)) {
					String price1 = cd.getCourses().getMobile().get(i).getPrice();
					System.out.println(price1);
				}			
			}
			
			System.out.println("7. print the all the coursetitle web automation");
			
			for (int i = 0; i < autSize; i++) {
				
				String webAutoCourseTitle1 = cd.getCourses().getWebAutomation().get(i).getCourseTitle();
				System.out.println(webAutoCourseTitle1);
				}
			
			System.out.println("8.CLIENT HAS GIVEN ECPEXTED LIST OF COURSES, YOU SHOULD MATCH WITH EXPECTED LIST OF COURSES UNDER WEB AUTOMATION");
			
			String s1[]= {"Selenium Webdriver Java","Cypress","Protractor"};
			List<String> expected3 = Arrays.asList(s1);
			
			List<WebAutomation> li = cd.getCourses().getWebAutomation();
			
			List<String> actual=new ArrayList<>();
			
			for (int i = 0; i < li.size(); i++) {
		
				actual.add(li.get(i).getCourseTitle());
			}
			
			Assert.assertTrue(expected3.equals(actual), "check the courses");
			System.out.println("PASS");
			
	System.out.println("9.CLIENT HAS GIVEN ECPEXTED LIST OF COURSES, YOU SHOULD MATCH WITH EXPECTED LIST OF COURSES UNDER MOBILE");
			
			String s2[]= {"Appium-Mobile Automation using Java"};
			List<String> expected4 = Arrays.asList(s2);
		
			List<Mobile> mLi = cd.getCourses().getMobile();
			
			List<String> mActual=new ArrayList<>();
			
			for (int i = 0; i < mLi.size(); i++) {
		
				mActual.add(mLi.get(i).getCourseTitle());
			}
			
			Assert.assertTrue(expected4.equals(mActual), "check the courses");
			System.out.println("PASS");
			
			
			System.out.println("10.CLIENT HAS GIVEN ECPEXTED LIST OF COURSES, YOU SHOULD MATCH WITH EXPECTED LIST OF COURSES UNDER API");
			
			String s3[]= {"Rest Assured Automation using Java","SoapUI Webservices testing"};
			List<String> expected5 = Arrays.asList(s3);
		
			List<Api> aLi = cd.getCourses().getApi();
			
			List<String> aActual=new ArrayList<>();
			
			for (int i = 0; i < aLi.size(); i++) {
		
				aActual.add(aLi.get(i).getCourseTitle());
			}
			
			Assert.assertTrue(expected5.equals(aActual), "check the courses");
			System.out.println("PASS");
	}	
}
