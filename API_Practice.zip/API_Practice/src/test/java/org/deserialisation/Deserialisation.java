package org.deserialisation;

import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;

import io.restassured.RestAssured;

public class Deserialisation {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://rahulshettyacademy.com";

		// POST - ACCESS TOKEN
		String postRes = given().log().all()
				.formParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
				.formParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W").formParam("grant_type", "client_credentials")
				.formParam("scope", "trust").when().post("/oauthapi/oauth2/resourceOwner/token").then().log().all()
				.assertThat().statusCode(200).extract().response().asString();

		String access_token = ReusableMethods.rawToJason(postRes, "access_token");
		System.out.println("Access_Token :" + access_token);
		
		
		// Get - the details
		
		CourseDetails cd = given().log().all().queryParam("access_token",access_token).
		when().get("/oauthapi/getCourseDetails").
		then().log().all().extract().response().as(CourseDetails.class);
		
		String ins = cd.getInstructor();
		System.out.println("Instructor :" + ins);
		
		String lin = cd.getLinkedIn();
		System.out.println("LinkedIn :" + lin);
		
		String ser = cd.getServices();
		System.out.println("Services :" + ser);
		
		String url = cd.getUrl();
		System.out.println("Url :" + url);
		
		String exp = cd.getExpertise();
		System.out.println("Expertise :" + exp);
		

		
		for (int i = 0; i < 3; i++) {
			
			String webAutoCourseTitle = cd.getCourses().getWebAutomation().get(i).getCourseTitle();
			System.out.println(webAutoCourseTitle);
			String price = cd.getCourses().getWebAutomation().get(i).getPrice();
			System.out.println(price);
			
		}
		for (int i = 0; i < 2; i++) {
			String courseTitle = cd.getCourses().getApi().get(i).getCourseTitle();
			System.out.println(courseTitle);
			String price = cd.getCourses().getApi().get(i).getPrice();
			System.out.println(price);
		}
		
		for (int i = 0; i < 1; i++) {
			String courseTitle = cd.getCourses().getMobile().get(i).getCourseTitle();
			System.out.println(courseTitle);
			String price = cd.getCourses().getMobile().get(i).getPrice();
			System.out.println(price);
		}
	}
}
