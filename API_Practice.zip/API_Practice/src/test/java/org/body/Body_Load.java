package org.body;

public class Body_Load {
	
	public static String post_Body() {
		
		
		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"Spencer Plaza\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Anna Salai, Thousand Lights, Chennai\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
	}
	
	public static String company1() {

		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"COMPANY1\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Chennai\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
			
	}
	
	public static String company2() {

		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"COMPANY2\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Madurai\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
			
	}

	public static String company3() {

		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"COMPANY3\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Coimbatore\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
			
	}

	public static String company4() {

		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"COMPANY4\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Trichy\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
			
	}
	
	public static String company5() {

		String s= "{\r\n" + 
				"  \"location\": {\r\n" + 
				"    \"lat\": 68.383494,\r\n" + 
				"    \"lng\": 97.427362\r\n" + 
				"  },\r\n" + 
				"  \"accuracy\": 80,\r\n" + 
				"  \"name\": \"COMPANY5\",\r\n" + 
				"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
				"  \"address\": \"Bangalore\",\r\n" + 
				"  \"types\": [\r\n" + 
				"    \"Mall\",\r\n" + 
				"    \"shop\"\r\n" + 
				"  ],\r\n" + 
				"  \"website\": \"http://google.com\",\r\n" + 
				"  \"language\": \"Tamil-IN\"\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
			
	}
	
	public static String coursePrice() {
		
		String s ="{\r\n" + 
				"  \"dashboard\": {\r\n" + 
				"    \"purchaseAmount\": 910,\r\n" + 
				"    \"website\": \"rahulshettyacademy.com\"\r\n" + 
				"  },\r\n" + 
				"  \"courses\": [\r\n" + 
				"    {\r\n" + 
				"      \"title\": \"Selenium Python\",\r\n" + 
				"      \"price\": 50,\r\n" + 
				"      \"copies\": 6\r\n" + 
				"    },\r\n" + 
				"    {\r\n" + 
				"      \"title\": \"Cypress\",\r\n" + 
				"      \"price\": 40,\r\n" + 
				"      \"copies\": 4\r\n" + 
				"    },\r\n" + 
				"    {\r\n" + 
				"      \"title\": \"RPA\",\r\n" + 
				"      \"price\": 45,\r\n" + 
				"      \"copies\": 10\r\n" + 
				"    }\r\n" + 
				"  ]\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
	}
	
	public static String createLib(String isbn,String aisle ) {
		String s="{\r\n" + 
				"\"name\":\"Learn SELENIUM WITH JAVA\",\r\n" + 
				"\"isbn\":\""+isbn+"\",\r\n" + 
				"\"aisle\":\""+aisle+"\",\r\n" + 
				"\"author\":\"ELANKO\"\r\n" + 
				"}";
		
		return s;
	}
	
	public static String createRealJira() {
		String s="{\r\n" + 
				"\"fields\": {\r\n" + 
				"        \"project\": {\r\n" + 
				"            \"key\": \"FC\"\r\n" + 
				"        },\r\n" + 
				"        \"summary\": \"QA || UNABLE TO LOGIN\",\r\n" + 
				"        \"description\": \"INVALID USERNAME AND INVALID PASSWORD\",\r\n" + 
				"        \"issuetype\": {\r\n" + 
				"            \"name\": \"Bug\"\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"  }\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
	}
	
	public static String createCom() {
		String s="{\r\n" + 
				"    \"body\": \"FIRST COMMENT\",\r\n" + 
				"    \"visibility\": {\r\n" + 
				"        \"type\": \"role\",\r\n" + 
				"        \"value\": \"Administrator\"\r\n" + 
				"    }\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
	}
	
	public static String updateCom() {
		String s="{\r\n" + 
				"    \"body\": \"FIRST COMMENT UPDATED\",\r\n" + 
				"    \"visibility\": {\r\n" + 
				"        \"type\": \"role\",\r\n" + 
				"        \"value\": \"Administrator\"\r\n" + 
				"    }\r\n" + 
				"}\r\n" + 
				"";
		
		return s;
	}
}
