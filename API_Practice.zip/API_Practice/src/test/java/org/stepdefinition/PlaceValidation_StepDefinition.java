package org.stepdefinition;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.base.ReusableMethods;
import org.base.TestData;
import org.serialisation.Location;
import org.serialisation.PlaceDetails;
import org.specificbuilder.AddPlaceDetails;
import org.testng.Assert;
import org.utilities.ApiResources;
import org.apache.groovy.parser.antlr4.GroovyParser.IfElseStatementContext;
import org.base.*;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class PlaceValidation_StepDefinition extends ReusableMethods {

	PlaceDetails pd;
	RequestSpecification reqSpec;
	ResponseSpecification resSpec;
	Response res;
	RequestSpecification givenReqSpec;

	@Given("Add place payload with {string} {string} {string}")
	public void add_place_payload_with(String name, String address, String language) throws IOException {

		reqSpec = ReusableMethods.reqSpecification();
		givenReqSpec = given().spec(reqSpec)
				.body(TestData.addPlace(name, address, language));
		resSpec = ReusableMethods.resSpecification();

	}
//
//	@When("User calls {string} with {string} Http request")
//	public void user_calls_with_Http_request(String resources,String httpMethod) {
//		ApiResources valueOf = ApiResources.valueOf(resources);
//		System.out.println(valueOf.getResource());
//		
//		if (httpMethod.equalsIgnoreCase("POST")) {
//			res = givenReqSpec.when().post(valueOf.getResource()).then().
//					spec(resSpec).extract().response();
//	
//		}else if (httpMethod.equalsIgnoreCase("GET")) {
//			res = givenReqSpec.when().get(valueOf.getResource()).then().
//					spec(resSpec).extract().response();
//		}else {
//			res = givenReqSpec.when().delete(valueOf.getResource()).then().
//					spec(resSpec).extract().response();
//		}
		
		
	@When("User calls {string} with {string} Http request")
	public void user_calls_with_Http_request(String resources, String httpMethod) {
		ApiResources valueOf = ApiResources.valueOf(resources);
		System.out.println(valueOf.getResource());
		
		if (httpMethod.equalsIgnoreCase("POST")) {
			res = givenReqSpec.when().post(valueOf.getResource()).then().
					spec(resSpec).extract().response();
	
		}else if (httpMethod.equalsIgnoreCase("GET")) {
			res = givenReqSpec.when().get(valueOf.getResource()).then().
					spec(resSpec).extract().response();
		}else {
			res = givenReqSpec.when().delete(valueOf.getResource()).then().
					spec(resSpec).extract().response();
		}
	
	}


	@Then("The APIs call got successful with status code {int}")
	public void the_APIs_call_got_successful_with_status_code(int expStatus) {

		int actualstatusCode = res.getStatusCode();
		Assert.assertEquals(actualstatusCode, expStatus);

	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String key, String expected) {

		String res1 = res.asString();
		JsonPath js = new JsonPath(res1);

		String actual = js.getString(key);
		Assert.assertEquals(actual, expected);
		System.out.println(key + ":" + expected);
	}

}
