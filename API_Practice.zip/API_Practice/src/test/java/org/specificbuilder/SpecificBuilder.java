package org.specificbuilder;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class SpecificBuilder {

	public static void main(String[] args) throws JsonProcessingException {

	
		// SERIALISATION JSON POST BODY
		PlaceDetails pd = new PlaceDetails();
		pd.setAccuracy("90");
		pd.setName("Infosys Technologies");
		pd.setPhone_number("(+91) 123 456 7890");
		pd.setAddress("29, navy mumbai");
		pd.setWebsite("http://google.com");
		pd.setLanguage("English-IN");

		Location l = new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		pd.setLocation(l);
		List<String> li = new ArrayList<>();
		li.add("herbal park");
		li.add("shop");
		pd.setTypes(li);

		// REQUEST SPECIFIC BUILDER

		RequestSpecification reqSpec = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addQueryParam("key", "qaclick123").setContentType(ContentType.JSON).build();

		// RESPONSE SPECIFIC BUILDER

		ResponseSpecification resSpec = new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).build();

		// ADD PLACE DETAILS

		AddPlaceDetails as = given().log().all().spec(reqSpec).body(pd).when().post("/maps/api/place/add/json").then()
				.log().all().spec(resSpec).extract().response().as(AddPlaceDetails.class);

		String status = as.getStatus();
		String place_id = as.getPlace_id();
		String scope = as.getScope();
		String reference = as.getReference();
		String id = as.getId();

		System.out.println("DESERIALISATION OF JSON POST RESPONSE");

		System.out.println("status" + " : " + status);
		System.out.println("place_id" + " : " + place_id);
		System.out.println("scope" + " : " + scope);
		System.out.println("reference" + " : " + reference);
		System.out.println("id" + " : " + id);

		// DELETE PLACE DETAILS

		// SERIALISATION JSON DELETE BODY

		DelPlaceBody db = new DelPlaceBody();
		db.setPlace_id(place_id);
		

		DelLocation as4 = given().log().all().spec(reqSpec).body(db).when().delete("/maps/api/place/delete/json").then()
				.log().all().spec(resSpec).extract().response().as(DelLocation.class);

		System.out.println("DESERIALISATION OF JSON DELETE RESPONSE");

		System.out.println(as4.getStatus());

		// GET THE PLACE DETAILS
		
		// RESPONSE SPECIFIC BUILDER

				ResponseSpecification resSpec1 = new ResponseSpecBuilder().expectStatusCode(404)
						.expectContentType(ContentType.JSON).build();


		GetLocation as3 = given().log().all().spec(reqSpec).queryParam("place_id", place_id).when()
				.get("/maps/api/place/get/json").then().log().all().spec(resSpec1).extract().response()
				.as(GetLocation.class);
		
		System.out.println("DESERIALISATION OF JSON GET RESPONSE");
		
		System.out.println(as3.getMsg());

		

	}

}
