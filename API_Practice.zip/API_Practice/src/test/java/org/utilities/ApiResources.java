package org.utilities;

public enum ApiResources {
	
	AddPlaceAPI("/maps/api/place/add/json"),
	GetPlaceAPI("/maps/api/place/get/json"),
	DeletePlaceAPI("/maps/api/place/delete/json");
	
	
	private String resource;
	
	
	public String getResource() {
		return resource;
	}
	
	ApiResources(String resource) {
		this.resource=resource;	}
	
//	ApiResources(String resource) {
//		this.resource=resource;
//	}

	
}
