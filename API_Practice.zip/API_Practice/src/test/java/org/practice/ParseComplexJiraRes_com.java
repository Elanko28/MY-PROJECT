package org.practice;

import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class ParseComplexJiraRes_com {

	public static void main(String[] args) {
		
		RestAssured.baseURI = "https://elanko28.atlassian.net";

		// CREATE AN ISSUE
		String postIssueRes = given().log().all().auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
				.body(Body_Load.createRealJira()).when().post("/rest/api/2/issue").then().log().all().assertThat()
				.statusCode(201).extract().response().asString();

		String resId = ReusableMethods.rawToJason(postIssueRes, "id");
		System.out.println("ISSUE ID :"+resId);

		// CREATE 10 comment
		
		for (int i = 1; i <= 10; i++) {
			
			String postComRes = given().log().all().pathParam("id", resId).auth().preemptive()
					.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
					.body("{\r\n" + 
							"    \"body\": \"COMMENT "+i+"\",\r\n" + 
							"    \"visibility\": {\r\n" + 
							"        \"type\": \"role\",\r\n" + 
							"        \"value\": \"Administrator\"\r\n" + 
							"    }\r\n" + 
							"}\r\n" + 
							"").when().post("/rest/api/2/issue/{id}/comment").then().log().all()
					.assertThat().statusCode(201).extract().response().asString();

			String comId = ReusableMethods.rawToJason(postComRes, "id");
			System.out.println("COMMENT ID :"+comId);
		}
			
			// Get the comment
			
			
			String getComRes = given().log().all().pathParam("issue", resId).queryParam("fields", "comment").
			auth().preemptive().basic("elanko28@gmail.com", ReusableMethods.jiraToken()).
			when().get("/rest/api/2/issue/{issue}").
			then().log().all().assertThat().statusCode(200).extract().response().asString();
			
			System.out.println(getComRes);
						
			JsonPath js=new JsonPath(getComRes);
			
			// print the no. of comments
			
			int comCount = js.getInt("fields.comment.comments.size()");
			System.out.println(comCount);
			
			// print the comment id
			
			for (int i = 0; i < comCount; i++) {
				
				int comId = js.getInt("fields.comment.comments["+i+"].id");
				System.out.println("comment id is : "+comId);
		
			}
			}
	
	}


