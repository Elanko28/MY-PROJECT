package org.practice;

import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;
import org.body.Body_Load;
import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class ParseComplexJiraRes_Com1 {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://elanko28.atlassian.net";

		// CREATE AN ISSUE
		String postIssueRes = given().log().all().auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
				.body(Body_Load.createRealJira()).when().post("/rest/api/2/issue").then().log().all().assertThat()
				.statusCode(201).extract().response().asString();

		String resId = ReusableMethods.rawToJason(postIssueRes, "id");
		System.out.println("ISSUE ID :"+resId);

		// CREATE 10 comment
	
		// QUESTION 3
		for (int i = 1; i <= 3; i++) {
			String expecCom="Comment "+i+"";
			String postComRes = given().log().all().pathParam("id", resId).auth().preemptive()
					.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
					.body("{\r\n" + 
							"    \"body\": \""+expecCom+"\",\r\n" + 
							"    \"visibility\": {\r\n" + 
							"        \"type\": \"role\",\r\n" + 
							"        \"value\": \"Administrator\"\r\n" + 
							"    }\r\n" + 
							"}\r\n" + 
							"").when().post("/rest/api/2/issue/{id}/comment").then().log().all()
					.assertThat().statusCode(201).extract().response().asString();

			String addComId = ReusableMethods.rawToJason(postComRes, "id");
	//		System.out.println("COMMENT ID :"+addComId);
		
			
			// Get the comment
			
			
			String getComRes = given().log().all().pathParam("issue", resId).queryParam("fields", "comment").
			auth().preemptive().basic("elanko28@gmail.com", ReusableMethods.jiraToken()).
			when().get("/rest/api/2/issue/{issue}").
			then().log().all().assertThat().statusCode(200).extract().response().asString();
			
						
			JsonPath js=new JsonPath(getComRes);
			int comCount = js.getInt("fields.comment.comments.size()");

			
	for (int j = 0; j < comCount; j++) {
				
				String comId = js.getString("fields.comment.comments["+j+"].id");
			//	System.out.println("comment id is : "+comId);
				
				if (addComId.equalsIgnoreCase(comId)) {
					String actualCom = js.getString("fields.comment.comments["+j+"].body");
					System.out.println(actualCom);
					Assert.assertEquals(expecCom, actualCom);
					System.out.println("comment passed");
				}
		
			}
			
			
		}
		String getComRes = given().log().all().pathParam("issue", resId).queryParam("fields", "comment").
				auth().preemptive().basic("elanko28@gmail.com", ReusableMethods.jiraToken()).
				when().get("/rest/api/2/issue/{issue}").
				then().log().all().assertThat().statusCode(200).extract().response().asString();
				
							
				JsonPath js=new JsonPath(getComRes);
			// QUESTION 1
			// print the no. of comments
			
			int comCount = js.getInt("fields.comment.comments.size()");
			System.out.println(comCount);
			// QUESTION 2
			// print the comment id
			
			for (int i = 0; i < comCount; i++) {
				
				String comId = js.getString("fields.comment.comments["+i+"].id");
				System.out.println("comment id is : "+comId);
		
			}

	}

}
