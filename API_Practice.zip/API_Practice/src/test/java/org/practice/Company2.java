package org.practice;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class Company2 {

	public static void main(String[] args) {
		

		RestAssured.baseURI = "https://rahulshettyacademy.com";

	
		String postRes = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body(Body_Load.company2()).when().post("/maps/api/place/add/json").then().log().all().assertThat()
				.statusCode(200).body("scope", equalTo("APP")).body("status", equalTo("OK"))
				.header("Server", equalTo("Apache/2.4.52 (Ubuntu)")).extract().response().asString();

		System.out.println(postRes);

		String pId = ReusableMethods.rawToJason(postRes, "place_id");
		System.out.println(pId);

		// UPDATE
		
		String placeUpdate ="Madurai-625001(1)";

		given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body("{\r\n" + "\"place_id\":\"" + pId + "\",\r\n"
						+ "\"address\":\""+placeUpdate+"\",\r\n"
						+ "\"key\":\"qaclick123\"\r\n" + "}\r\n" + "")
				.when().put("/maps/api/place/update/json").then().log().all().assertThat().statusCode(200);

		// GET THE UPDATE (TASK)

		given().log().all().queryParam("key", "qaclick123").queryParam("place_id", pId).when()
				.get("/maps/api/place/get/json").then().log().all().assertThat().statusCode(200);

		// DELETE THE PLACE

		given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body("{\r\n" + "    \"place_id\":\""+pId+"\"\r\n" + "}\r\n" + "").when()
				.delete("/maps/api/place/delete/json").then().log().all().assertThat().statusCode(200);

	}
}


