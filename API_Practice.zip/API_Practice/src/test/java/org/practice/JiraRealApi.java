package org.practice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class JiraRealApi {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://elanko28.atlassian.net";

		given().log().all().auth().preemptive().basic("elanko28@gmail.com",
				"ATATT3xFfGF073KKNXL2pvMM_RgBoc8ZCGpg3WBhmMLaMt0r-qh5rQrEsCRT3XvpREv-xYRUSRj1_3-bvb79TQ1Ih52i5XA1K-H3DsdYJmsUdqghIeOUHDbLyvwyQxXQ7IjUYxJSRtRkbSdwWv9dsg2p2SDBXgeWhudQbxkCXmPFX4PVJPdTObU=9445AC18")
				.when().get("/rest/api/2/search").then().log().all().assertThat().statusCode(200);
	}

}
