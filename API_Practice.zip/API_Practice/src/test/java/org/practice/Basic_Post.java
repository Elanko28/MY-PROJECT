package org.practice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class Basic_Post {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://rahulshettyacademy.com";

		given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body("{\r\n" + 
						"  \"location\": {\r\n" + 
						"    \"lat\": 68.383494,\r\n" + 
						"    \"lng\": 97.427362\r\n" + 
						"  },\r\n" + 
						"  \"accuracy\": 80,\r\n" + 
						"  \"name\": \"Spencer Plaza\",\r\n" + 
						"  \"phone_number\": \"(+91) 9600488942\",\r\n" + 
						"  \"address\": \"Anna Salai, Thousand Lights, Chennai\",\r\n" + 
						"  \"types\": [\r\n" + 
						"    \"Mall\",\r\n" + 
						"    \"shop\"\r\n" + 
						"  ],\r\n" + 
						"  \"website\": \"http://google.com\",\r\n" + 
						"  \"language\": \"Tamil-IN\"\r\n" + 
						"}\r\n" + 
						"")
				.when().post("/maps/api/place/add/json").then().log().all().assertThat().statusCode(200);

	}

}
