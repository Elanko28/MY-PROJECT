package org.practice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;

public class JiraRealApi_GetAll_Issues {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://elanko28.atlassian.net";

		given().log().all().auth().preemptive().basic("elanko28@gmail.com",
				ReusableMethods.jiraToken())
				.when().get("/rest/api/2/search").then().log().all().assertThat().statusCode(200);
	}

}
