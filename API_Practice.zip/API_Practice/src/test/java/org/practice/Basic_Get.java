package org.practice;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;

public class Basic_Get {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://rahulshettyacademy.com";

		given().log().all().queryParam("key", "qaclick123").
		queryParam("place_id", "2594c7eda484d5fed83d628810f827df").
		when().get("/maps/api/place/get/json").then().log().all().assertThat().statusCode(200);

	}

}
