package org.practice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;

public class GetSpecificCom {

	public static void main(String[] args) {

		RestAssured.baseURI="https://elanko28.atlassian.net";
		
		given().log().all().pathParam("issue", "FC-19").queryParam("fields", "comment").
		auth().preemptive().basic("elanko28@gmail.com", ReusableMethods.jiraToken()).
		when().get("/rest/api/2/issue/{issue}").
		then().log().all().assertThat().statusCode(200);
	}

}
