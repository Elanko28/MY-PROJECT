package org.practice;

import static io.restassured.RestAssured.*;

import java.io.File;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class Jira_FileAttachment {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://elanko28.atlassian.net";

		// Adding the attachement
		
		File f= new File("D:\\classes\\API\\Day 12\\AttachemntFile.txt");

		given().log().all().pathParam("issue", "FC-17").header("X-Atlassian-Token", "no-check").multiPart(f)
				.header("Content-Type", "multipart/form-data").auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken())
				.when().post("/rest/api/2/issue/{issue}/attachments").
				then().log().all().assertThat().statusCode(200);
	}

}
