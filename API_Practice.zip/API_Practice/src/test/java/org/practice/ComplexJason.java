package org.practice;

import org.body.Body_Load;

import io.restassured.path.json.JsonPath;

public class ComplexJason {

	public static void main(String[] args) {
		 
		JsonPath js = new JsonPath(Body_Load.coursePrice());
		int total=0;
		// 1. Print No of courses returned by API
		
		int courseCount = js.getInt("courses.size()");
		System.out.println(courseCount);
		
		// 2.Print Purchase Amount
		
		int purchaseAmount = js.getInt("dashboard.purchaseAmount");
		System.out.println(purchaseAmount);
		
		//3. Print Title of the first course
		
		String title = js.get("courses[0].title");
		System.out.println(title);
		
		// 4. Print All course titles and their respective Prices
		
			for (int i = 0; i < 3; i++) {
				String title1 = js.get("courses["+i+"].title");
				System.out.println(title1);
				
				int price = js.getInt("courses["+i+"].price");
				System.out.println(price);				
			}
			
		// 5. Print no of copies sold by RPA Course
			
			int copies = js.getInt("courses[2].copies");
			System.out.println("RPA  "+copies);
			
		//	6. Verify if Sum of all Course prices matches with Purchase Amount
			
			for (int i = 0; i < 3; i++) {
				String title1 = js.get("courses["+i+"].title");
				
				int price = js.getInt("courses["+i+"].price");
				
				int copies1 = js.getInt("courses["+i+"].copies");
				
				System.out.println(title1+" "+ copies1+" "+price);
				
				total=total+( copies1 * price);
				
			}
			System.out.println(total);
				
			if (total==purchaseAmount) {
				 System.out.println("Sum of all Course prices are matched with Purchase Amount");
			} else {
				System.out.println("Sum of all Course prices are not matched with Purchase Amount");
			}
	}

}
