package org.practice;

import static io.restassured.RestAssured.given;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class Qauth_Post_Get {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://rahulshettyacademy.com";

		// POST - ACCESS TOKEN
		String postRes = given().log().all()
				.formParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
				.formParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W").formParam("grant_type", "client_credentials")
				.formParam("scope", "trust").when().post("/oauthapi/oauth2/resourceOwner/token").then().log().all()
				.assertThat().statusCode(200).extract().response().asString();

		String access_token = ReusableMethods.rawToJason(postRes, "access_token");
		System.out.println("Access_Token :" + access_token);
		
		
		// Get - the details
		
		given().log().all().queryParam("access_token",access_token).
		when().get("/oauthapi/getCourseDetails").
		then().log().all().assertThat().statusCode(401);


	}

}
