package org.practice;

import static org.hamcrest.Matchers.equalTo;
import static org.base.ReusableMethods.*;
import org.body.Body_Load;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class DynamicJson {
	
	@Test(dataProvider="BooksData")
	private void createLib(String s1, String s2) {
		RestAssured.baseURI ="http://216.10.245.166";
		// CREATE LIB
		String postRes = given().log().all().header("Content-Type", "application/json")
				.body(Body_Load.createLib(s1, s2)).
				when().post("/Library/Addbook.php").
				then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		String id = rawToJason(postRes, "ID");
		// GET1 LIB
		given().log().all().queryParam("AuthorName", "ELANKO").when()
		.get("/Library/GetBook.php").then().log().all().assertThat().statusCode(200);
		// GET2 LIB
		given().log().all().queryParam("ID", id).when()
		.get("/Library/GetBook.php").then().log().all().assertThat().statusCode(200);
		// DELETE LIB
		String delRes = given().log().all().body("{\r\n" + 
				" \r\n" + 
				"\"ID\" : \""+id+"\"\r\n" + 
				" \r\n" + 
				"} \r\n" + 
				"").
		when().delete("/Library/DeleteBook.php").
		then().log().all().assertThat().statusCode(200).extract().response().asString();
	}
	
	@DataProvider(name="BooksData")
	public Object[][] inputData() {
		return new Object[][] {
			{"elanko","123456"},
			{"elanko1","123456"},
			{"elanko2","123456"}
		};
		}}
