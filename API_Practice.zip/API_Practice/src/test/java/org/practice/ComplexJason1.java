package org.practice;

import org.body.Body_Load;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import io.restassured.path.json.JsonPath;

public class ComplexJason1 {
	
	JsonPath js = new JsonPath(Body_Load.coursePrice());
	// 1. Print No of courses returned by API

	@Test(priority=1)
	
	public void printCourse() {
		int courseCount = js.getInt("courses.size()");
		System.out.println(courseCount);
	}
	
	// 2.Print Purchase Amount
	
	@Test(priority=2)
	private void purAmount() {
		int purchaseAmount = js.getInt("dashboard.purchaseAmount");
		System.out.println(purchaseAmount);
	}
	
	//3. Print Title of the first course

	@Test(priority=3)
	private void printTitle() {
		String title = js.get("courses[0].title");
		System.out.println(title);

	}
	
	// 4. Print All course titles and their respective Prices
	
	@Test(priority=4)
	private void printAll() {
		int courseCount = js.getInt("courses.size()");
		
		for (int i = 0; i < courseCount; i++) {
			String title1 = js.getString("courses["+i+"].title");
			System.out.println(title1);
			
			int price = js.getInt("courses["+i+"].price");
			System.out.println(title1+"  : "+price);				
		}
		}
	
	// 5. Print no of copies sold by RPA Course

	@Test(priority=5)
	private void rpa() {
		int courseCount = js.getInt("courses.size()");
		
		
		for (int i = 0; i < courseCount; i++) {
			String title1 = js.getString("courses["+i+"].title");
			if (title1.equalsIgnoreCase("RPA")) {
				int copies = js.getInt("courses["+i+"].copies");
				System.out.println("RPA  :"+ copies);
			
			}
			}
		}
	
	//	6. Verify if Sum of all Course prices matches with Purchase Amount

	@Test(priority=6)
	private void checkTotal() {
			int total=0;
			int courseCount = js.getInt("courses.size()");
			int purchaseAmount = js.getInt("dashboard.purchaseAmount");


		for (int i = 0; i < courseCount; i++) {
			String title1 = js.get("courses["+i+"].title");
			
			int price = js.getInt("courses["+i+"].price");
			
			int copies1 = js.getInt("courses["+i+"].copies");
			
			System.out.println(title1+" "+ copies1+" "+price);
			
			total=total+( copies1 * price);
			
		}
		System.out.println(total);
		
		Assert.assertEquals(total, purchaseAmount, "not equal, has to check");
		 System.out.println("Sum of all Course prices are matched with Purchase Amount");

}}
	



