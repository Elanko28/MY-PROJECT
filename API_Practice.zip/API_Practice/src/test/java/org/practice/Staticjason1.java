package org.practice;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.body.Body_Load;
import org.testng.annotations.Test;
public class Staticjason1 {

	public static void main(String[] args) throws IOException {
			
		
		Path path = Paths.get("D:\\classes\\API\\DAY 8\\ComplexJson.json");
		byte[] readAllBytes = Files.readAllBytes(path);
		String s=new String(readAllBytes);
		
			
		JsonPath js = new JsonPath(s);
		// 1. Print No of courses returned by API

			int courseCount = js.getInt("courses.size()");
			System.out.println(courseCount);
			
			// 2.Print Purchase Amount

			
			int purchaseAmount = js.getInt("dashboard.purchaseAmount");
			System.out.println(purchaseAmount);
		
		

	}


	}


