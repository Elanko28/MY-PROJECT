package org.practice;

import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class JiraRealApi_Create_Del_Issues {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://elanko28.atlassian.net";
		// CREATE AN ISSUE
		String postRes = given().log().all().auth().preemptive().basic("elanko28@gmail.com",
			ReusableMethods.jiraToken()).header("Content-Type", "application/json").body(Body_Load.createRealJira())
				.when().post("/rest/api/2/issue").then().log().all().assertThat().statusCode(201).
				extract().response().asString();
		
		String resId = ReusableMethods.rawToJason(postRes, "id");
		System.out.println(resId);
		
		// DELETE AN ISSUE
		
		given().log().all().pathParam("id", resId).
		auth().preemptive().basic("elanko28@gmail.com", ReusableMethods.jiraToken()).
		when().delete("/rest/api/2/issue/{id}").then().log().all().assertThat().statusCode(204);
		
			
	}

	
}
