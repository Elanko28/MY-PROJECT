package org.practice;

import static io.restassured.RestAssured.*;

import org.base.ReusableMethods;
import org.body.Body_Load;

import io.restassured.RestAssured;

public class JiraRealApiFull_Com {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://elanko28.atlassian.net";

		// CREATE AN ISSUE
		String postIssueRes = given().log().all().auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
				.body(Body_Load.createRealJira()).when().post("/rest/api/2/issue").then().log().all().assertThat()
				.statusCode(201).extract().response().asString();

		String resId = ReusableMethods.rawToJason(postIssueRes, "id");
		System.out.println("ISSUE ID :"+resId);

		// CREATE comment
		String postComRes = given().log().all().pathParam("id", resId).auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
				.body(Body_Load.createCom()).when().post("/rest/api/2/issue/{id}/comment").then().log().all()
				.assertThat().statusCode(201).extract().response().asString();

		String comId = ReusableMethods.rawToJason(postComRes, "id");
		System.out.println("COMMENT ID :"+comId);

		// UPDATE comment

		String putComRes = given().log().all().pathParam("id", resId).pathParam("id1", comId).auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).header("Content-Type", "application/json")
				.body(Body_Load.updateCom()).when().put("/rest/api/2/issue/{id}/comment/{id1}").then().log().all()
				.assertThat().statusCode(200).extract().response().asString();

		System.out.println(putComRes);

		// Get the comment

		String getComRes = given().log().all().pathParam("id", resId).auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).when().get("/rest/api/2/issue/{id}/comment")
				.then().log().all().assertThat().statusCode(200).extract().response().asString();

		System.out.println(getComRes);

		// DELETE a comment

		given().log().all().pathParam("id", resId).pathParam("id1", comId).auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).when()
				.delete("/rest/api/2/issue/{id}/comment/{id1}").then().log().all().assertThat().statusCode(204);

		// DELETE AN ISSUE

		given().log().all().pathParam("id", resId).auth().preemptive()
				.basic("elanko28@gmail.com", ReusableMethods.jiraToken()).when().delete("/rest/api/2/issue/{id}").then()
				.log().all().assertThat().statusCode(204);

	}

}
