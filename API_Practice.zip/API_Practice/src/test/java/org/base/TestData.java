package org.base;

import java.util.ArrayList;
import java.util.List;

import org.serialisation.Location;
import org.serialisation.PlaceDetails;

import io.restassured.RestAssured;

public class TestData {

	
	public static PlaceDetails addPlace(String name, String address, String language) {
		
		RestAssured.baseURI = "https://rahulshettyacademy.com";

		PlaceDetails pd = new PlaceDetails();
		pd.setAccuracy("90");
		pd.setName(name);
		pd.setPhone_number("(+91) 123 456 7890");
		pd.setAddress(address);
		pd.setWebsite("http://google.com");
		pd.setLanguage(language);

		Location l = new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		pd.setLocation(l);
		List<String> li = new ArrayList<>();
		li.add("herbal park");
		li.add("shop");
		pd.setTypes(li);
		
		return pd;

	}
	
	public static PlaceDetails addplace() {

		RestAssured.baseURI = "https://rahulshettyacademy.com";

		PlaceDetails pd = new PlaceDetails();
		pd.setAccuracy("90");
		pd.setName("infotech");
		pd.setPhone_number("(+91) 123 456 7890");
		pd.setAddress("34,insta nagar");
		pd.setWebsite("http://google.com");
		pd.setLanguage("english");

		Location l = new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		pd.setLocation(l);
		List<String> li = new ArrayList<>();
		li.add("herbal park");
		li.add("shop");
		pd.setTypes(li);
		
		return pd;

	}
}
