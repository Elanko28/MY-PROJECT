package org.base;
import org.utilities.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReusableMethods {
	
	static RequestSpecification reqSpec;

	public static String rawToJason(String res, String path) {

		JsonPath js = new JsonPath(res);
		String s = js.get(path);

		return s;
	}

	public static String load_Static_Json(String path) throws IOException {
		Path path1 = Paths.get(path);
		byte[] readAllBytes = Files.readAllBytes(path1);
		String s = new String(readAllBytes);

		return s;
	}

	public static String jiraToken() {

		String token = "ATATT3xFfGF073KKNXL2pvMM_RgBoc8ZCGpg3WBhmMLaMt0r-qh5rQrEsCRT3XvpREv-xYRUSRj1_3-bvb79TQ1Ih52i5XA1K-H3DsdYJmsUdqghIeOUHDbLyvwyQxXQ7IjUYxJSRtRkbSdwWv9dsg2p2SDBXgeWhudQbxkCXmPFX4PVJPdTObU=9445AC18";

		return token;
	}

	public static RequestSpecification reqSpecification() throws IOException {
		
		
		if (reqSpec==null) {
			PrintStream log = new PrintStream(new FileOutputStream("test.txt"));

			reqSpec = new RequestSpecBuilder().setBaseUri(getGlobalValue("BaseUrl"))
					.addQueryParam("key", "qaclick123").setContentType(ContentType.JSON).
					addFilter(RequestLoggingFilter.logRequestTo(log)).	
					addFilter(ResponseLoggingFilter.logResponseTo(log)).build();
		}
		
		return reqSpec;
	}

	public static ResponseSpecification resSpecification() {
		ResponseSpecification resSpec = new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON).build();

		return resSpec;
	}

	public static String getGlobalValue(String globalKey) throws IOException {
		
		Properties prop=new Properties();
		FileInputStream fis=new FileInputStream("C:\\Users\\elank\\API_Practice\\src\\test\\java\\org\\utilities\\global.properties");
		prop.load(fis);
		String value = prop.getProperty(globalKey);
		System.out.println(value);
		return value;
	}

}
