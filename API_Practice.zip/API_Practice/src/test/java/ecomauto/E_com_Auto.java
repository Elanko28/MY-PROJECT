package ecomauto;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import java.io.File;


public class E_com_Auto {

	public static void main(String[] args) {

		// LOGIN DETAILS

		LoginDetails ld = new LoginDetails();
		ld.setUserEmail("elanko28@gmail.com");
		ld.setUserPassword("Elanko123");

		RequestSpecification logReqSpec = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.setContentType(ContentType.JSON).build();

		RequestSpecification givenReq = given().log().all().spec(logReqSpec).body(ld);

		LogRes lr = givenReq.when().post("/api/ecom/auth/login").then().log().all().assertThat().statusCode(200).extract()
				.response().as(LogRes.class);

		String token = lr.getToken();
		String userId = lr.getUserId();
		String message = lr.getMessage();
		System.out.println(token);
		System.out.println(userId);
		System.out.println(message);

		// CREATE PRODUCT
		// PRODUCT 1
		File f = new File("D:\\classes\\API\\Day 19\\camera.jpg");

		RequestSpecification creProdReq = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
				.addHeader("Authorization", token).build();

		RequestSpecification creProdGiven = given().log().all().spec(creProdReq).formParam("productName", "camera")
				.formParam("productAddedBy", userId).formParam("productCategory", "electronics")
				.formParam("productSubCategory", "cameras").formParam("productPrice", "115000")
				.formParam("productDescription", "canon").formParam("productFor", "men").multiPart("productImage", f);

		String creProdRes = creProdGiven.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();
		// PRODUCT 1
		System.out.println("PRODUCT 1");
		JsonPath js=new JsonPath(creProdRes);
		String productId1 = js.getString("productId");
		String mes1 = js.getString("message");
		System.out.println(productId1);
		System.out.println(mes1);
		
		// PRODUCT 2
		
		File f2 = new File("D:\\classes\\API\\Day 19\\SHOE.png");
		RequestSpecification creProdGiven2 = given().log().all().spec(creProdReq).formParam("productName", "SHOE")
				.formParam("productAddedBy", userId).formParam("productCategory", "fashion")
				.formParam("productSubCategory", "shoes").formParam("productPrice", "7500")
				.formParam("productDescription", "BEST SHOES").formParam("productFor", "men").multiPart("productImage", f2);

		String creProdRes2 = creProdGiven2.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();
		// PRODUCT 2
		System.out.println("PRODUCT 2");
		JsonPath js2=new JsonPath(creProdRes2);
		String productId2 = js2.getString("productId");
		String mes2 = js2.getString("message");
		System.out.println(productId2);
		System.out.println(mes2);

		
		// PRODUCT 3
		

		File f3 = new File("D:\\classes\\API\\Day 19\\LAPTOP.png");
		RequestSpecification creProdGiven3 = given().log().all().spec(creProdReq).formParam("productName", "LAPTOP")
				.formParam("productAddedBy", userId).formParam("productCategory", "electronics")
				.formParam("productSubCategory", "laptops").formParam("productPrice", "150000")
				.formParam("productDescription", "BEST LAPTOP").formParam("productFor", "men").multiPart("productImage", f3);

		String creProdRes3 = creProdGiven3.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();
		// PRODUCT 3
		System.out.println("PRODUCT 3");
		JsonPath js3=new JsonPath(creProdRes3);
		String productId3 = js3.getString("productId");
		String mes3 = js3.getString("message");
		System.out.println(productId3);
		System.out.println(mes3);

		// PRODUCT 4
		
		File f4 = new File("D:\\classes\\API\\Day 19\\MOBILE.png");
		RequestSpecification creProdGiven4 = given().log().all().spec(creProdReq).formParam("productName", "MOBILE")
				.formParam("productAddedBy", userId).formParam("productCategory", "electronics")
				.formParam("productSubCategory", "mobiles").formParam("productPrice", "65000")
				.formParam("productDescription", "BEST MOBILE").formParam("productFor", "men").multiPart("productImage", f4);

		String creProdRes4 = creProdGiven4.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();
		// PRODUCT 4
		System.out.println("PRODUCT 4");
		JsonPath js4=new JsonPath(creProdRes4);
		String productId4 = js4.getString("productId");
		String mes4 = js4.getString("message");
		System.out.println(productId4);
		System.out.println(mes4);

		
		
		// PRODUCT 5
		
		File f5 = new File("D:\\classes\\API\\Day 19\\TSHIRT.png");
		RequestSpecification creProdGiven5 = given().log().all().spec(creProdReq).formParam("productName", "TSHIRT")
				.formParam("productAddedBy", userId).formParam("productCategory", "fashion")
				.formParam("productSubCategory", "t-shirts").formParam("productPrice", "1500")
				.formParam("productDescription", "BEST TSHIRT").formParam("productFor", "men").multiPart("productImage", f5);

		String creProdRes5 = creProdGiven5.when().post("/api/ecom/product/add-product").then().log().all().extract()
				.response().asString();
		// PRODUCT 5
		System.out.println("PRODUCT 5");
		JsonPath js5=new JsonPath(creProdRes5);
		String productId5 = js5.getString("productId");
		String mes5 = js5.getString("message");
		System.out.println(productId5);
		System.out.println(mes5);



	}

}
