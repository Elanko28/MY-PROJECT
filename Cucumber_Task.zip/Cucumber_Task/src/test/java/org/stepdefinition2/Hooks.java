package org.stepdefinition2;

import java.util.Date;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	
	@Before
	public void beforeAll() {
		System.out.println("Scenario is going to initiate");
		Date d= new Date();
		System.out.println(d);

	}
	
	
	@After
	public void afterAll() {
		System.out.println("Scenario has finised");
		Date d= new Date();
		System.out.println(d);
	}
	
	
}
