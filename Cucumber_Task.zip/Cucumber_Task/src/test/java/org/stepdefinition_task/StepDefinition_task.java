package org.stepdefinition_task;

import org.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.testng.AmazonLogin1_POJO;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_task extends BaseClass {
	
	
	@Given("User have to launch the Amazon application through chrome browser")
	public void user_have_to_launch_the_Amazon_application_through_chrome_browser() {
		launchBrowser();

		loadUrl("https://www.amazon.in/");

	}

	@When("User have to enter the invalid username and invalid  password in amazon login page")
	public void user_have_to_enter_the_invalid_username_and_invalid_password_in_amazon_login_page() {
		AmazonLogin1_POJO am = new AmazonLogin1_POJO();
		WebElement login = am.getLoginP();
		toClick(login);
		WebElement email = am.getEmailP();
		toSendKeys(email, "asd123@gmail.com");

	}

	@When("User have to click the login button in amazon login page")
	public void user_have_to_click_the_login_button_in_amazon_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("User have to reach the invalid credential page in amazon login page")
	public void user_have_to_reach_the_invalid_credential_page_in_amazon_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}


}
