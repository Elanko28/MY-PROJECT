package org.runner;

import org.base.JVMReport;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)

@CucumberOptions(features="C:\\Users\\elank\\Cucumber_Task\\src\\test\\resources\\FeatureFile\\Login_Basic.feature",
				glue="org.stepdefinition3",plugin="rerun:Failed\\fail.txt")

public class TestRunner_rerun_plugin {

}
