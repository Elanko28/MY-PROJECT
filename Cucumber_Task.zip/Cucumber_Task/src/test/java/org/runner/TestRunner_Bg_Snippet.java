package org.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)

@CucumberOptions(features="C:\\Users\\elank\\Cucumber_Task\\src\\test\\resources\\FeatureFile\\Login_Bg_Snippet.feature",
				glue="org.stepdefinition",snippets=SnippetType.CAMELCASE)


public class TestRunner_Bg_Snippet {

}
