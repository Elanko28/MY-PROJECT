package org.sample;

public class Class7_pom_sample {
	
	
	public static void main(String[] args) {
	Class7_Pom c=new Class7_Pom();
	
	c.setAge(25);
	int age = c.getAge();
	System.out.println("age: "+age);
}
}
