package org.practice;

public class Code_Practice_Day2 {

	public static void main(String[] args) {
/*		
	System.out.println("8. to check the given number is armstrong or not");
	
	int num=153;
	int n=num;
	
	int rem=0;
	int res=0;
	
	while (num>0) {
		
		rem=num%10;
		res=(rem*rem*rem)+res;
		num=num/10;
	}
	if (n==res) {
		System.out.println("the given number is armstrong");
	} else {
		System.out.println("the given number is not armstrong");
	}
*/
/*		
	System.out.println("9.find the sum of digits in a given number");	
	int num=125;
	
	int rem=0;
	int res=0;
	
	while (num>0) {
		
		rem=num%10;
		res=res+rem;
		num=num/10;
		}
	System.out.println(res);
*/
/*
		System.out.println("10.find the product of digits in a given number");	
		int num=128;
		
		int rem=0;
		int res=1;
		
		while (num>0) {
			
			rem=num%10;
			res=res*rem;
			num=num/10;
			}
		System.out.println(res);
*/
/*	
	System.out.println("11.find the count of the digits in a given number");
	
	int num=34672;
	int count=0;
	while (num>0) {
		count++;
		num=num/10;
	}
	System.out.println(count);
*/
/*
		System.out.println("12. find the factorial of 5");
		int fact=1;
		int num=5;
	for (int i = 1; i < num; i++) {
		fact=fact*i;
	}
	System.out.println(fact);
*/
		System.out.println("13.fibbonacci series for the given number");
	
		int a=0;
		int b=1;
		System.out.println(a);
		System.out.println(b);
		
		for (int i = 1; i <=5; i++) {
			int c=a+b;
			System.out.println(c);
			
			a=b;
			b=c;
		}

	}

}
