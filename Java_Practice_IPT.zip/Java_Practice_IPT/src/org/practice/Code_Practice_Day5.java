package org.practice;

import java.util.LinkedHashMap;
import java.util.Map;

public class Code_Practice_Day5 {

	public static void main(String[] args) {
/*		
		System.out.println("26. to find the count of each word in string");
		String s= "java sql python java oracle";
		String[] sp = s.split(" ");
		Map<String, Integer> mp=new LinkedHashMap<>();
		for (int i = 0; i < sp.length; i++) {
			String s1=sp[i];
			if (mp.containsKey(s1)) {
				Integer count = mp.get(s1);
				mp.put(s1, count+1);
			} else {
				mp.put(s1, 1);
			}
		}
		System.out.println(mp);
*/
/*	
		System.out.println("27. to find the vowel and consonant in the given string");
		String s="to find the vowel and consonant in the given string";
		int space=0;
		int vowCount=0;
		String vow="";
		String cons="";
		int consCount=0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c==' ') {
				space++;
			} else if (c=='a'||c=='e'||c=='i'||c=='o'||c=='u') {
				vow=vow+c;
				vowCount++;
			}else {
				cons=cons+c;
				consCount++;
			}
			}
		System.out.println("space :"+space);
		System.out.println("vowCount :"+vowCount);
		System.out.println("vow :"+vow);
		System.out.println("cons :"+cons);
		System.out.println("consCount :"+consCount);
*/
		
		System.out.println("27. to find the uppercase, lowercase, digits and special character in the given string");
		String s="QWErtyuiop23456@#$%^&@.gmail.com";
		String upper="";
		String lower="";
		String number="";
		String spl="";
		for (int i = 0; i < s.length(); i++) {
			char s1=s.charAt(i);
			int x=s1;
		if (x>=65&&x<=90) {
			upper=upper+s1;
		} else if (x>=97&&x<=122) {
			lower=lower+s1;
		} else if (x>=48&&x<=57) {
			number=number+s1;
		}else {
			spl=spl+s1;
		}
		}
		System.out.println("uppercase :"+upper);
		System.out.println("lowercase :"+lower);
		System.out.println("number :"+number);
		System.out.println("spl char :"+spl);

	}
}
