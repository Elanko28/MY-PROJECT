package org.practice;

import java.util.Arrays;

public class Code_Practice_Day11 {

	public static void main(String[] args) {
/*		
		System.out.println("28. to find the uppercase, lowercase, digits and special character in the given string");
		String s="QWErtyuiop23456@#$%^&@.gmail.com";
		String upper="";
		String lower="";
		String number="";
		String spl="";
		for (int i = 0; i < s.length(); i++) {
			char s1=s.charAt(i);
					
		if (s1>='A'&&s1<='Z') {
			upper=upper+s1;
		} else if (s1>='a'&&s1<='z') {
			lower=lower+s1;
		} else if (s1>='0'&&s1<='9') {
			number=number+s1;
		}else {
			spl=spl+s1;
		}
		}
		System.out.println("uppercase :"+upper);
		System.out.println("lowercase :"+lower);
		System.out.println("number :"+number);
		System.out.println("spl char :"+spl);
*/
/*		
		System.out.println("29. to find the uppercase, lowercase, digits and special character in the given string using predefined methods");
		String s="QWErtyuiop23456@#$%^&@.gmail.com";
		String upper="";
		String lower="";
		String number="";
		String spl="";
		for (int i = 0; i < s.length(); i++) {
			char s1=s.charAt(i);
					
		if (Character.isUpperCase(s1)) {
			upper=upper+s1;
		} else if (Character.isLowerCase(s1)) {
			lower=lower+s1;
		} else if (Character.isDigit(s1)) {
			number=number+s1;
		}else {
			spl=spl+s1;
		}
		}
		System.out.println("uppercase :"+upper);
		System.out.println("lowercase :"+lower);
		System.out.println("number :"+number);
		System.out.println("spl char :"+spl);
*/
/*
		System.out.println("30.To sort the character in the given string");
		
		String s="goodday";
		char[] c = s.toCharArray();
		
		for (int i = 0; i < c.length; i++) {
			for (int j = i+1; j < c.length; j++) {
				if(c[i]>c[j]) {
					char temp=c[i];
					c[i]=c[j];
					c[j]=temp;
					}
					}
	}
		for (char d : c) {
			System.out.print(d);
		}
*/
		System.out.println("31. To check the given two strings aee Anagram or not");
		
		String s1="secure";
		String s2="rescue";
		
		if(s1.length()==s2.length()) {
			char[] c1 = s1.toCharArray();
			char[] c2 = s2.toCharArray();
			Arrays.sort(c1);
			Arrays.sort(c2);
			if (Arrays.equals(c1, c2)) {
				System.out.println("Anagram");
			}else {
				System.out.println("Not anagram - due to character is not matching");
			}
			
		}
		else {
			System.out.println("not anagram - due to length is not matching");
		}
}}
