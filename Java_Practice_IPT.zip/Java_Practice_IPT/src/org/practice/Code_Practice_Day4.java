package org.practice;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

class Code_Practice_Day4 {

	public static void main(String[] args) {
/*	
		System.out.println("19.to remove the character duplicates from String");
		
		String s="raining here....";
		Set<Character> si=new LinkedHashSet<>();
		for (int i = 0; i < s.length(); i++) {
			char c=s.charAt(i);
			si.add(c);
		}
		for (Character x : si) {
			System.out.print(x);
		}
*/
/*		
	System.out.println("19.to remove the character duplicates from String");
		
		String s="raining here....";
		Set<Character> si=new LinkedHashSet<>();
		for (int i = 0; i < s.length(); i++) {
			char c=s.charAt(i);
			si.add(c);
		}
		String res="";
		for (Character x : si) {
			res=res+x;
		}
		System.out.println(res);
*/
/*		
	System.out.println("20.to remove word duplicates from a string");
	String s="java sql java python java python";
	String[] sp=s.split(" ");
	Set<String> si=new LinkedHashSet<>();
	for (int i = 0; i < sp.length; i++) {
		String s1 = sp[i];
		si.add(s1);
	}
	for (String x : si) {
		System.out.println(x);
	}
*/
/*
	System.out.println("21. to remove the duplicates and to sort elements from array");
	int a[]= {55,39,26,78,55,99,30,26,78};
	Set<Integer> si= new TreeSet<>();
	for (int i = 0; i < a.length; i++) {
		int x=a[i];
		si.add(x);
	}
	for (Integer x : si) {
		System.out.println(x);
	}
*/
/*	
		System.out.println("22. to sort elements numbers in ascending order");
		int a[]= {55,39,26,78,55,99,30,26,78};
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				
				if (a[i]>a[j]) {
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			}
		for (int i : a) {
		System.out.println(i);	
		}
*/
/*		
		System.out.println("23. to sort elements numbers in descending order");
		int a[]= {55,39,26,78,55,99,30,26,78};
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				
				if (a[i]<a[j]) {
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
			}
		for (int i : a) {
		System.out.println(i);	
		}
*/
		
	System.out.println("24. to find the count of each character in string");
	String s="elanko thangarajan";
	Map<Character,Integer> mp=new LinkedHashMap<>();
	for (int i = 0; i < s.length(); i++) {
		char c=s.charAt(i);
		if (mp.containsKey(c)) {
			Integer count=mp.get(c);
			mp.put(c, count+1);
		}
		else {
			mp.put(c, 1);
		}
	}
	Set<Entry<Character, Integer>> entrySet = mp.entrySet();
	System.out.println(entrySet);
	System.out.println(mp);

	}
	

		
}
