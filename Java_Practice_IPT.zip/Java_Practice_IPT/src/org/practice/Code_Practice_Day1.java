package org.practice;

public class Code_Practice_Day1 {

	public static void main(String[] args) {

		/*
		 * System.out.println("1.FIND THE ODD OR EVEN NUMBER"); int num=23;
		 * 
		 * if (23%2==0) { System.out.println("the given number is even");
		 * 
		 * } else { System.out.println("the given number is odd");
		 * 
		 * }
		 */
		/*
		 * System.out.println("2.print all the odd numbers between 1 to 100");
		 * 
		 * for (int i = 0; i < 100; i++) {
		 * 
		 * 
		 * if (i%2==1) { System.out.println("the given number is odd  "+i);
		 * 
		 * } }
		 */
		
/*		
		System.out.println("3.count the odd numbers between 1 to 100");

		int count = 0;

		for (int i = 0; i < 100; i++) {

			if (i % 2 == 1) {
				count++;
			}
		}
		System.out.println(count);
*/
	/*	
		System.out.println("4.count the even numbers between 1 to 100");

		int count = 0;

		for (int i = 0; i < 100; i++) {

			if (i % 2 == 0) {
				count++;
			}
		}
		System.out.println(count);
*/
/*		
		System.out.println("5.REVERSE THE GIVEN NUMBER");
		
		int num=123;
		int rem=0;
		int result=0;
		
		while (num>0) {
			
			rem=num%10;
			result=(result*10)+rem;
			num=num/10;
			}
		System.out.println(result);
*/
/*		
		System.out.println("6. To check palindrome or not");
		
		int num=123;
		int n=num;
		int rem=0;
		int result=0;
		
		while (num>0) {
			
			rem=num%10;
			result=(result*10)+rem;
			num=num/10;
			}
		if (result==n) {
			System.out.println("the given number is palindrome");
		} else {
			System.out.println("the given number is not palindrome");
		}
*/
		
	}
}
