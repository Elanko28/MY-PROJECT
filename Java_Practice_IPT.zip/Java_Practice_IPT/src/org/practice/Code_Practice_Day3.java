package org.practice;

public class Code_Practice_Day3 {

	public static void main(String[] args) {
/*		
		System.out.println("14.find the reverse of the given string");
		
		String s="welcome to the java class";
		
		String rev="";
		for (int i = s.length()-1; i >=0; i--) {
			char c=s.charAt(i);
			rev=rev+c;
		}
		System.out.println(rev);
*/
/*		
		System.out.println("15.check wheather the given string is palindrome or not");
		
		String s ="malayalam";
		String rev="";
		for (int i = s.length()-1; i >=0; i--) {
			char c=s.charAt(i);
			rev=rev+c;
			}
		if (s.equals(rev)) {
			
			System.out.println("the given string is palindrome");
			
		} else {
			System.out.println("the given string is not palindrome");
		}
*/
/*
		System.out.println("16. to find the reverse of each word enhanced for loop");
	
	String s="welcome to java class";
	String[] sp=s.split(" ");
	String res="";
	for (String s1 : sp) {
		String rev="";
		for (int i = s1.length()-1; i >=0; i--) {
			
			char c=s1.charAt(i);
			rev=rev+c;
		}
		res=res+rev+" ";
			}
	System.out.println(res);
*/
/*		
		System.out.println("17. find the reverse of each word using only for loop");
		String s="welcome to java class";
		String[] sp=s.split(" ");
		String res="";
		for (int i = 0; i < sp.length; i++) {
			String s1=sp[i];
			String rev="";
			for (int j = s1.length()-1; j >=0; j--) {
			char c = s1.charAt(j);	
			rev=rev+c;
			}
			res=res+rev+" ";
		}
		System.out.println(res);
*/
/*
		System.out.println("17.To change the each word's first letter to uppercase");
		String s="welcome to java class";
		String[] sp=s.split(" ");
		String res="";
		for (int i = 0; i < sp.length; i++) {
			String s1=sp[i];
			char s2 = s1.charAt(0);
			char cap = Character.toUpperCase(s2);
			String sub = s1.substring(1);
			res=res+cap+sub+" ";
			}
		System.out.println(res);
*/
		System.out.println("TASK-17.To change the each word's LAST letter to uppercase");
		String s="welcome to java class";
		String[] sp=s.split(" ");
		String res="";
		for (int i = 0; i < sp.length; i++) {
			String s1=sp[i];
		int lastIndex = s1.length()-1;
		int firsIndex=0;
		char s2 = s1.charAt(lastIndex);
		char cap = Character.toUpperCase(s2);
		String sub = s1.substring(firsIndex, lastIndex);
		res=res+sub+cap+" ";
		}
		System.out.println(res);
	}

}
