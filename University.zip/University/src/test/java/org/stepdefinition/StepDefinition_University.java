package org.stepdefinition;

import io.cucumber.java.en.Given;

import org.base.BaseClass;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.*;

public class StepDefinition_University extends BaseClass{
	
	public By cookies = By.xpath("//button[text()='YES I AGREE']");
	public By courses=By.xpath("(//a[@class='nvhdlnk'])[4]");
	public By ug_Courses=By.xpath("//a[text()='FIND UNDERGRADUATE COURSES ']");
	public By chooseYourSubject=By.xpath("//input[@id='chooseYourSubject']");
	public By law=By.xpath("//a[@name='Law']");
	public By landingSearch=By.xpath("//button[@id='landingSearch']");
	public By law2=By.xpath("//li[text()='Law']");
	public By gradeOption=By.xpath("//a[@id='gradeOption']");
	public By region=By.xpath("//a[text()='REGION']");
	public By university=By.xpath("//a[text()='UNIVERSITY']");
	public By courseType=By.xpath("//a[text()='COURSE TYPE']");
	public By qualification=By.xpath("//a[text()='QUALIFICATION']");
	
	
	
	
	@Given("To launch the chrome browser and hit the url")
	public void to_launch_the_chrome_browser_and_hit_the_url() {
		try {
			BaseClass.launchBrowser();
			BaseClass.loadUrl("https://www.thecompleteuniversityguide.co.uk/");
			BaseClass.toImplicitWait(10);
			WebElement cookies1 = driver.findElement(cookies);
			BaseClass.toClick(cookies1);
			BaseClass.maximize();
			
		} catch (Exception e) {
		e.printStackTrace();	
		}
		

	}

	@When("Move to undergraduate courses")
	public void move_to_undergraduate_courses() throws InterruptedException {
		try {
			Thread.sleep(2000);
			WebElement courses1 = driver.findElement(courses);
			BaseClass.toMoveToElement(courses1);
			Thread.sleep(2000);
			WebElement ug_Courses1 = driver.findElement(ug_Courses);
			BaseClass.toexecuteScriptClick(ug_Courses1);
			
		} catch (Exception e) {
				e.printStackTrace();		}
		
	}

	@When("Search courses")
	public void search_courses() {
		
		try {
			BaseClass.toImplicitWait(10);

			WebElement courseName1 = driver.findElement(chooseYourSubject);
			BaseClass.toSendKeys(courseName1, "law");
			WebElement law1 = driver.findElement(law);
			Thread.sleep(3000);
			BaseClass.toexecuteScriptClick(law1);
			WebElement search = driver.findElement(landingSearch);
			boolean displayed = search.isDisplayed();
			System.out.println(displayed);
			BaseClass.toexecuteScriptClick(search);;
			
		} catch (Exception e) {
				e.printStackTrace();		}
	}

	@Then("Check the text in the page")
	public void check_the_text_in_the_page() {
	try {
		BaseClass.toImplicitWait(10);
		Thread.sleep(2000);
		WebElement breadCrumb = driver.findElement(law2);
		BaseClass.toGetText(breadCrumb);
		String text = breadCrumb.getText();
		Assert.assertEquals(text, "Law");
	//	Thread.sleep(2000);
		WebElement grades = driver.findElement(gradeOption);
		BaseClass.toGetText(grades);
		WebElement region1 = driver.findElement(region);
		BaseClass.toGetText(region1);
		WebElement university1 = driver.findElement(university);
		BaseClass.toGetText(university1);
		WebElement courseType1 = driver.findElement(courseType);
		BaseClass.toGetText(courseType1);
		WebElement qualification1 = driver.findElement(qualification);
		BaseClass.toGetText(qualification1);
		BaseClass.toQuit();

	} catch (Exception e) {
		e.printStackTrace();	}	
	}

	@When("click the page number two")
	public void click_the_page_number_two() throws InterruptedException {
		WebElement nextPage = driver.findElement(By.xpath("(//a[text()='2'])[1]"));
		BaseClass.toScrollDown(nextPage);
		BaseClass.toClick(nextPage);
		Thread.sleep(3000);;
	}

	@Then("check wheather it reached the page number two")
	public void check_wheather_it_reached_the_page_number_two() {
		try {
			String currentUrl = driver.getCurrentUrl();
			System.out.println(currentUrl);
			if (currentUrl.contains("pg=2")) {
				System.out.println("second page reached");
			} else {
			System.out.println("second  page not reached");
			}
			BaseClass.toQuit();
		} catch (Exception e) {
			e.printStackTrace();		
			}
		
	}


}
