package org.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.utilities.JVMReport;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)

@CucumberOptions(features = "C:\\Users\\elank\\University\\src\\test\\resources\\FeaturesFile\\University.feature", 
glue = "org.stepdefinition",plugin={"json:C:\\Users\\elank\\University\\Report\\Json_Report\\University.json"})

public class TestRunner_University {
	
	@AfterClass
	public static void aft() {
		JVMReport.generateJVMReport("C:\\Users\\elank\\University\\Report\\Json_Report\\University.json");
	}

}
