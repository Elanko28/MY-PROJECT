package org.base;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class University extends BaseClass {
	
	public static void main(String[] args) throws AWTException, InterruptedException {
		
		launchBrowser();
		
		loadUrl("https://www.thecompleteuniversityguide.co.uk/");
		
		toImplicitWait(10);

		WebElement cookies = driver.findElement(By.xpath("//button[text()='YES I AGREE']"));

		toClick(cookies);
		maximize();
		Thread.sleep(2000);

		WebElement courses = driver.findElement(By.xpath("(//a[@class='nvhdlnk'])[4]"));

		BaseClass.toMoveToElement(courses);
		
		Thread.sleep(2000);

		WebElement ug_Courses = driver.findElement(By.xpath("//a[text()='FIND UNDERGRADUATE COURSES ']"));

		toexecuteScriptClick(ug_Courses);
		
		WebElement courseName = driver.findElement(By.xpath("//input[@id='chooseYourSubject']"));
		
		toSendKeys(courseName, "law");
		WebElement law = driver.findElement(By.xpath("//a[@name='Law']"));
		Thread.sleep(2000);
		toexecuteScriptClick(law);

		
		WebElement search = driver.findElement(By.xpath("//button[@id='landingSearch']"));
		boolean displayed = search.isDisplayed();
		System.out.println(displayed);
		toexecuteScriptClick(search);
		
		WebElement breadCrumb = driver.findElement(By.xpath("//li[text()='Law']"));
		toGetText(breadCrumb);
		WebElement grades = driver.findElement(By.xpath("//a[@id='gradeOption']"));
		toGetText(grades);
		WebElement region = driver.findElement(By.xpath("//a[text()='REGION']"));
		toGetText(region);
		WebElement university = driver.findElement(By.xpath("//a[text()='UNIVERSITY']"));
		toGetText(university);
		WebElement courseType = driver.findElement(By.xpath("//a[text()='COURSE TYPE']"));
		toGetText(courseType);
		WebElement qualification = driver.findElement(By.xpath("//a[text()='QUALIFICATION']"));
		toGetText(qualification);
		WebElement nextPage = driver.findElement(By.xpath("(//a[text()='2'])[1]"));
		toScrollDown(nextPage);
		toClick(nextPage);
		Thread.sleep(3000);;

		String currentUrl = driver.getCurrentUrl();
		System.out.println(currentUrl);
		if (currentUrl.contains("pg=2")) {
			System.out.println("second page reached");
			
		} else {
			
			System.out.println("second  page not reached");


		}


		toQuit();
		
		
		
	}

}
